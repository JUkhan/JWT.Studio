
import home from 'Scripts/Components/home/homeSvc.js';

var moduleName='app.services';

angular.module(moduleName,[])
.factory('homeSvc', home);

export default moduleName;