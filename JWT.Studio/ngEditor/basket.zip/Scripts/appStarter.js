
 import app from 'Scripts/Base/app.js';
      
 angular.bootstrap(document, [app]);