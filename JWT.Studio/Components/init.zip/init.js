﻿
var init = 100;
export init;