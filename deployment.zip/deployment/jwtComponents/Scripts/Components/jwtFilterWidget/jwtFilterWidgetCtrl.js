class jwtFilterWidgetCtrl
{
	constructor(){
		this.name='jwtFilter';
      	this.description='It is usefull to communicate amoungs widgets.';
	}
}
export default jwtFilterWidgetCtrl;