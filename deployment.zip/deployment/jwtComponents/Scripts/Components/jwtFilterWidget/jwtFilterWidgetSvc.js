class jwtFilterWidgetSvc
{
	constructor(){
	}
	static jwtFilterWidgetFactory()	{
		return new jwtFilterWidgetSvc();
	}
}
export default jwtFilterWidgetSvc.jwtFilterWidgetFactory;