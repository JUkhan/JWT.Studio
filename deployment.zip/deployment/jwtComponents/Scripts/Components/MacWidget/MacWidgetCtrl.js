class MacWidgetCtrl
{
	constructor(){
		this.name='mac';
      	this.description='this is a test component.';
	}
}
export default MacWidgetCtrl;