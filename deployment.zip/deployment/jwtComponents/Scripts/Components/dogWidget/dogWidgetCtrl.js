class dogWidgetCtrl
{
	constructor(){
		this.name='dog';
      	this.description='This is native dog.';
	}
}
export default dogWidgetCtrl;