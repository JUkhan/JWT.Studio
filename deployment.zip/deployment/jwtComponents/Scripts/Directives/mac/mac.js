class mac{
  
    constructor(){

      this.restrict='ECA';  
      this.templateUrl='Scripts/Directives/mac/mac.html';
      this.replace=true;
    }  
  
   static builder(){ 
      return  new mac(); 
   }
}

export default mac;