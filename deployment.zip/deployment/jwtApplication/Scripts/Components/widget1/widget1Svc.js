class widget1Svc
{
	constructor(){
	}
	static widget1Factory()	{
		return new widget1Svc();
	}
}
export default widget1Svc.widget1Factory;