class widget1Ctrl
{
	constructor(){
		this.title='widget1';
	}
}
export default widget1Ctrl;