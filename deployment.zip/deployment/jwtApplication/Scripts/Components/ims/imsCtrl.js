class imsCtrl
{
	constructor(){
		this.title='ims';
	}
}
export default imsCtrl;