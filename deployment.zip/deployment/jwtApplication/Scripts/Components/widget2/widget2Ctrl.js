class widget2Ctrl
{
	constructor(){
		this.title='widget2';
	}
}
export default widget2Ctrl;