class widget2Svc
{
	constructor(){
	}
	static widget2Factory()	{
		return new widget2Svc();
	}
}
export default widget2Svc.widget2Factory;