class rootCtrl
{
	constructor(){
		this.title='root';
	}
}
export default rootCtrl;