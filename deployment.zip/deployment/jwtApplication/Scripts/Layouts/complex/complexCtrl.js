class complexCtrl
{
	constructor(){
		this.title='complex';
	}
}
export default complexCtrl;