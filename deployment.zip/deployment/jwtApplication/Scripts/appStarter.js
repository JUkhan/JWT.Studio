
 import {default as app} from 'Scripts/app.js';
      
 angular.bootstrap(document, [app]);